var WshShell = new ActiveXObject("WScript.Shell");
var oShellLink = WshShell.CreateShortcut(FolderView.FocusItem.Path);
FolderView.open(oShellLink.TargetPath);