//===================mknewtxt.js=====================
objFso = new ActiveXObject( "Scripting.FileSystemObject" );
objWsh = new ActiveXObject( "WScript.Shell" );
strDTxtReg = objWsh.RegRead( "HKCR\\.txt\\" );
strTxtReg = objWsh.RegRead( "HKCR\\" + strDTxtReg + "\\" );
strFileName = FolderView.Path + "\\�V�K" + strTxtReg + "\.txt";
for ( i = 2 ; objFso.FileExists( strFileName ) ; i++ ) {
strFileName = FolderView.Path + "\\�V�K" + strTxtReg + " (" + i + ")\.txt";
}
objFso.CreateTextFile( strFileName );
FolderView.Refresh(2);
MDIE.Command( 5226 );
MDIE.Command( 5206 );