MDIE.Clipboard(FolderView.FocusItem.Path);
MDIE.echo(MDIE.Clipboard);