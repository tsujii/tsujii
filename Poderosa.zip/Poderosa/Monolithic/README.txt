Monolithic Poderosa is a single executable file that can run without dlls.

To make a Monolithic Poderosa,

 1. download ILMerge from Microsoft and install it.
 2. run make-monolithic.bat in this folder.

Limitations:

 - When Monolithic Poderosa starts, additional plugin dlls are not loaded.
