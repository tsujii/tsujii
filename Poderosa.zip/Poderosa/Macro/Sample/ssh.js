import Poderosa;
import Poderosa.ConnectionParam;
import Poderosa.Terminal;
import Poderosa.Macro;
import Poderosa.View;
import System.Drawing;

var env = new Environment();

/*
    Please modify the following values before you run this macro!
*/
var host = "192.168.0.151";
var account = "root";
var password = "rootroot";

sshLogin();

function sshLogin() {
    var param = new SSHTerminalParam(ConnectionMethod.SSH2, host, account, password);
    
    var prof = new RenderProfile();
    prof.FontSize = 10;
    prof.FontName = "Courier New";
    prof.SetBackColor(Color.Black);
    prof.SetForeColor(Color.White);
    param.RenderProfile = prof;

    //Telnet negotiation
    var c = env.Connections.Open(param);
    var r = c.ReceiveData();
    while(r.indexOf("login:")==-1) r = c.ReceiveData(); //waiting prompt for account
    c.TransmitLn(account);
    r = c.ReceiveData();
    while(r.indexOf("Password:")==-1) r = c.ReceiveData(); //waiting prompt for password
    c.TransmitLn(password);

}
